# BUILD PLAN — 40 - THE BISHOP WHO GAVE IN SECRET

Slug: `40_the_bishop_who_gave_in_secret` · Content type: **History & the Saints** · Duration: VO 108.000s + 2.0s end card = 110.000s · pre_roll_sec 0.0
19 generated shots (5 / 5 / 4 / 5) · 3 BLACK shots · 19 unique stills · no still reuse

## Concept

The story of Nicholas and the three bags of gold plays out as its own night-time film in an ancient Mediterranean town, lit only by small clay oil lamps: the hooded giver is always seen from behind, at a distance, or by his hands, so the camera itself keeps his request — *tell no one*. It opens cold on the modern myth (an empty red costume behind a sleet-streaked shop window) and cuts hard to warm for the real bishop walking away into a dark lane. Father Geula appears only at the three framing points: the honest aside ('We know very little', profile), the confession ('There is a camera pointed at me right now', the only direct-to-lens shot — the line is about this camera), and the close ('Let your Father see it', kneeling from behind, seen by no one but God). 'Now look at us' cuts to the cold world, where the window gift is inverted: a phone filming its own coin, a man filming his own prayer. The close translates the window into today — a hand leaving a bag on a doorstep and a man walking away unseen, a visual callback to SHOT_02. Warm = the hidden gift and faith; cold = the performed one. Hard cuts only; two BLACK cards hold the two sentences that matter most ('Tell no one.' and Matthew 6:3).

## What the alignment changed

- 'He had three daughters … no future he could give them.' runs 26.945–36.947s (10.0s, over the Flow ceiling): split at the 0.52s pause after 'marriage,' into SHOT_07 (6.881s) and SHOT_08 (3.121s).
- 'Then, another night… a second. The third time, the father was waiting.' is one 7.421s shot (SHOT_10, near ceiling) — two purses on the table carry 'a second', so no extra slot is spent.
- 'We cannot fast, or pray, or help a friend… without making sure someone noticed.' is 7.261s (SHOT_16, near ceiling); kept whole because it is one image.
- The Scripture plus 'Matthew six.' and the following 1.46s breath run 8.882s — longer than a generated shot may be, so it is a BLACK card (SHOT_18), which also suits the brand's Scripture grammar.
- 'He ran out … It was the bishop.' (6.621s) fits one shot, so the chase and the reveal are a single calm image: the hand on the cloak and the bishop's stole.

## Shot list

| Shot | Still | Palette | VO coverage | Target | Creative note | Audio note |
|---|---|---|---|---|---|---|
| SHOT_01 | STILL_A | COLD | Before he was a man in a red suit… | 3.741s | Hook. 'Before he was a man in a red suit…' The modern myth, seen cold and from outside: an empty costume, nobody inside it. Generic costume on a faceless mannequin — no character, face or brand depicted. | AMB_NIGHT bed in from VIDEO_START. |
| SHOT_02 | STILL_B | WARM | he was a bishop who did not want to be seen. Nicholas. | 5.301s | Hard cut cold → warm on 'he was a bishop who did not want to be seen. Nicholas.' The real man: anonymous, hooded, turned away, leaving. Opening half of the walking-away callback (SHOT_20). | Bed only. |
| SHOT_03 | STILL_C | WARM (dawn) | Bishop of Myra, on the coast of what is now Turkey, in the fourth century. | 6.341s | 'Bishop of Myra, on the coast of what is now Turkey, in the fourth century.' Place carries the shot. Atmospheric evocation of a Lycian coastal town — not documentary Myra/Demre. The Reel's ONE deliberate generated camera move. | Bed only. |
| SHOT_04 | STILL_D | WARM | We know very little about him for certain. | 3.100s | 'We know very little about him for certain.' Father Geula's first framing appearance — the honest aside, in profile, not addressing the lens. | Bed only. |
| SHOT_05 | STILL_E | WARM | But the Church has told one story about him for more than a thousand years. | 5.421s | 'But the Church has told one story about him for more than a thousand years.' A thousand years of remembering shown through one more candle. Tier 1 generic icon, unnamed; Tier 3 human angle (the hand). | Bed only. |
| SHOT_06 | STILL_F | WARM (dim) | A man in his town had fallen into poverty. | 3.041s | 'A man in his town had fallen into poverty.' The story begins: anonymous, face hidden. | Bed only. |
| SHOT_07 | STILL_G | WARM (dim) | He had three daughters and nothing for their dowries — and without one, there was no marriage, | 6.881s | 'He had three daughters and nothing for their dowries — and without one, there was no marriage,' Anonymous, from behind, veiled. | Bed only. |
| SHOT_08 | STILL_H | WARM (dim) | and no future he could give them. | 3.121s | 'and no future he could give them.' The empty dowry chest — the need made into one object. | Bed only. |
| SHOT_09 | STILL_I | WARM | One night, a bag of gold came through his window. | 4.561s | 'One night, a bag of gold came through his window.' The gift itself, from outside; the giver unseen. Cover frame. | Bed only. |
| SHOT_10 | STILL_J | WARM (dim) | Then, another night… a second. The third time, the father was waiting. | 7.421s | 'Then, another night… a second. The third time, the father was waiting.' Two purses already on the table carry 'a second'; the waiting man carries the third night. | Bed only. |
| SHOT_11 | STILL_K | WARM | He ran out into the street and caught the man who had thrown it. It was the bishop. | 6.621s | 'He ran out into the street and caught the man who had thrown it. It was the bishop.' The reveal is the stole, never the face. Calm hold, no struggle. | ACCENT_01 SFX_FOOTSTEP on 'He ran out'. |
| SHOT_12 | STILL_L | WARM | And Nicholas asked him for one thing. | 2.781s | 'And Nicholas asked him for one thing.' Hands only — the request is intimate, not public. | Bed only. |
| SHOT_13 | BLACK | BLACK | Tell no one. | 2.040s | BLACK content card: 'Tell no one.' (TEXT_02). | Bed continues under the card. |
| SHOT_14 | STILL_M | WARM | That part did not work. Which is why you know the story. | 4.561s | 'That part did not work. Which is why you know the story.' The secret written down and handed on — the dry joke made visible. | Bed only. |
| SHOT_15 | STILL_N | COLD | Now look at us. We cannot give a coin without filming it. | 4.581s | Hard cut warm → cold on 'Now look at us. We cannot give a coin without filming it.' The bishop's window, inverted. | Bed only. |
| SHOT_16 | STILL_O | COLD | We cannot fast, or pray, or help a friend… without making sure someone noticed. | 7.261s | 'We cannot fast, or pray, or help a friend… without making sure someone noticed.' Piety performed for the lens. | Bed only. |
| SHOT_17 | STILL_P | WARM | I include myself, brother. There is a camera pointed at me right now. | 6.301s | 'I include myself, brother. There is a camera pointed at me right now.' The only direct-to-lens shot — the line is about this very camera. | Bed only. |
| SHOT_18 | BLACK | BLACK | "When thou doest alms, let not thy left hand know what thy right hand doeth." Matthew six. | 8.882s | BLACK Scripture card: Matthew 6:3 excerpt (TEXT_03) through 'Matthew six.' | SILENCE_01 — bed muted for the Scripture. |
| SHOT_19 | STILL_Q | WARM | So this week, do one good thing that no one will ever know about. | 5.101s | 'So this week, do one good thing that no one will ever know about.' The window gift translated into today — warm palette returns with the act. | Bed returns after SILENCE_01. |
| SHOT_20 | STILL_R | WARM | Not your friends. Not your feed. Not even the man you help, if you can manage it. | 6.741s | 'Not your friends. Not your feed. Not even the man you help, if you can manage it.' Callback to SHOT_02: the giver walks away unseen. | Bed only. |
| SHOT_21 | STILL_S | WARM | Let your Father see it. That is enough. | 4.201s | 'Let your Father see it. That is enough.' Prayer in secret — he is seen only by the One he kneels to, and from behind by us. | ACCENT_02 SFX_CLOTH on 'Let your Father'; ACCENT_03 SFX_BELL at the cut to black (VO_AUDIO_END). |
| SHOT_22 | BLACK | BLACK | — | 2.000s | End card: hard cut to BLACK, @FatherGeula (TEXT_05). | SFX_BELL rings out at the cut; bed under the card. |

## Sound

- Bed: **AMB_NIGHT** — almost the whole story is night (the window, the waiting, the street) and the close is private prayer.
- Accents (3): SFX_FOOTSTEP on 'He ran out' (the only physical action in the story); SFX_CLOTH on 'Let your Father' (Father Geula kneeling); SFX_BELL at VO_AUDIO_END on the cut to black.
- Intentional silence: SILENCE_01 mutes the bed for the Matthew 6:3 card (BEFORE 'When thou doest' → BEFORE 'So this week'). Every other pause is a natural VO pause, not a silence event.
- Library suggestions (non-executable): SFX_COIN_PURSE, AMB_STREET_NIGHT_ANCIENT.

## Flags

- No 📷 REAL FOOTAGE NEEDED flags: the script names no specific icon, fresco, relic or church. 'Myra' is evoked generically in SHOT_03 (not documentary Myra/Demre).
- TEXT_03 Matthew 6:3 is an **excerpt** (the verse begins 'But' and ends with a colon) — labelled '(excerpt)'; verified word-for-word against two KJV sources.
- SHOT_01: generic red holiday costume on a faceless mannequin — no face, no brand, no lettering.
- Near ceiling: SHOT_10 (7.421s), SHOT_16 (7.261s).
- The bishop's face is never shown; every historical figure is hooded, from behind, silhouetted, or hands-only.

## Duplication notes

- No still reuse: 19 stills, 19 generated shots.
- Callback (intentional): SHOT_02 (the bishop walking away down a lane) ↔ SHOT_20 (the modern giver walking away down a street). Different era, framing and light; same meaning.
- Continuity (intentional): the hooded bishop recurs in SHOT_02, SHOT_09 and SHOT_11 — one character across the story, each time with a different framing and action (walking away wide; giving at the window, medium; caught and revealed, medium with foreground hand).
- Visual rhyme (intentional): the window gift (SHOT_09) ↔ the phone gift (SHOT_15) ↔ the doorstep gift (SHOT_19) — the same act, hidden, performed, then hidden again.
- Father Geula bookend: profile aside (SHOT_04) → frontal address (SHOT_17) → kneeling from behind (SHOT_21); three different compositions.
