# EDITING SUMMARY — 40 - THE BISHOP WHO GAVE IN SECRET

Format 1080×1920 · 9:16 · 30 fps · H.264 · pre_roll_sec 0.0 · render profile father_geula_render_v1 · anchor resolver normalized_tokens_v1
Source clip policy: playback_rate 1.0 · source in 0.0 · overlength TRIM_END · underlength ERROR · hard cuts only
Total running time 110.000s (VO 108.000s + 2.0s end card)

## Timeline

| Shot | Position | Duration | Source | Start | End |
|---|---|---|---|---|---|
| SHOT_01 | 0.000–3.741s | 3.741s | SHOT_01 | VIDEO_START | BEFORE "he was a bishop" |
| SHOT_02 | 3.741–9.042s | 5.301s | SHOT_02 | PREVIOUS_SHOT_END | BEFORE "Bishop of Myra" |
| SHOT_03 | 9.042–15.383s | 6.341s | SHOT_03 | PREVIOUS_SHOT_END | BEFORE "We know very little" |
| SHOT_04 | 15.383–18.483s | 3.100s | SHOT_04 | PREVIOUS_SHOT_END | BEFORE "But the Church has" |
| SHOT_05 | 18.483–23.904s | 5.421s | SHOT_05 | PREVIOUS_SHOT_END | BEFORE "A man in his town" |
| SHOT_06 | 23.904–26.945s | 3.041s | SHOT_06 | PREVIOUS_SHOT_END | BEFORE "He had three daughters" |
| SHOT_07 | 26.945–33.826s | 6.881s | SHOT_07 | PREVIOUS_SHOT_END | BEFORE "and no future" |
| SHOT_08 | 33.826–36.947s | 3.121s | SHOT_08 | PREVIOUS_SHOT_END | BEFORE "One night" |
| SHOT_09 | 36.947–41.508s | 4.561s | SHOT_09 | PREVIOUS_SHOT_END | BEFORE "Then another night" |
| SHOT_10 | 41.508–48.929s | 7.421s | SHOT_10 | PREVIOUS_SHOT_END | BEFORE "He ran out" |
| SHOT_11 | 48.929–55.550s | 6.621s | SHOT_11 | PREVIOUS_SHOT_END | BEFORE "And Nicholas asked" |
| SHOT_12 | 55.550–58.331s | 2.781s | SHOT_12 | PREVIOUS_SHOT_END | BEFORE "Tell no one" |
| SHOT_13 | 58.331–60.371s | 2.040s | BLACK | PREVIOUS_SHOT_END | BEFORE "That part did not work" |
| SHOT_14 | 60.371–64.932s | 4.561s | SHOT_14 | PREVIOUS_SHOT_END | BEFORE "Now look at us" |
| SHOT_15 | 64.932–69.513s | 4.581s | SHOT_15 | PREVIOUS_SHOT_END | BEFORE "We cannot fast" |
| SHOT_16 | 69.513–76.774s | 7.261s | SHOT_16 | PREVIOUS_SHOT_END | BEFORE "I include myself" |
| SHOT_17 | 76.774–83.075s | 6.301s | SHOT_17 | PREVIOUS_SHOT_END | BEFORE "When thou doest" |
| SHOT_18 | 83.075–91.957s | 8.882s | BLACK | PREVIOUS_SHOT_END | BEFORE "So this week" |
| SHOT_19 | 91.957–97.058s | 5.101s | SHOT_19 | PREVIOUS_SHOT_END | BEFORE "Not your friends" |
| SHOT_20 | 97.058–103.799s | 6.741s | SHOT_20 | PREVIOUS_SHOT_END | BEFORE "Let your Father" |
| SHOT_21 | 103.799–108.000s | 4.201s | SHOT_21 | PREVIOUS_SHOT_END | VO_AUDIO_END |
| SHOT_22 | 108.000–110.000s | 2.000s | BLACK | PREVIOUS_SHOT_END | FIXED_DURATION 2.0s |

## Text events

| ID | Style | Placement | Content | In | Out | Fallback |
|---|---|---|---|---|---|---|
| TEXT_01 | HOOK | LOWER_THIRD | Before the red suit, / there was a bishop. | VIDEO_START (0.000s) | BEFORE "Bishop of Myra" (9.042s) | null |
| TEXT_02 | STATEMENT | BLACK_CARD_CENTER | Tell no one. | ON "Tell no one" (58.331s) | BEFORE "That part did not work" (60.371s) | null |
| TEXT_03 | SCRIPTURE | BLACK_CARD_CENTER | When thou doest alms, let not thy left hand know what thy right hand doeth. / — Matthew 6:3 (excerpt) | ON "When thou doest" (83.075s) | BEFORE "So this week" (91.957s) | null |
| TEXT_04 | STATEMENT | CENTER_LOW | Let your Father see it. | ON "Let your Father" (103.799s) | VO_AUDIO_END (108.000s) | null |
| TEXT_05 | HANDLE | BLACK_CARD_CENTER_SMALL | @FatherGeula | VO_AUDIO_END (108.000s) | FIXED_DURATION 2.0s (110.000s) | null |

## Silence events

| ID | Start | End | mute_bed |
|---|---|---|---|
| SILENCE_01 | BEFORE "When thou doest" (83.075s) | BEFORE "So this week" (91.957s) | true |

## Accent events

| ID | Sound | Trigger |
|---|---|---|
| ACCENT_01 | SFX_FOOTSTEP | ON "He ran out" (48.929s) |
| ACCENT_02 | SFX_CLOTH | ON "Let your Father" (103.799s) |
| ACCENT_03 | SFX_BELL | VO_AUDIO_END (108.000s) |

## Audio

Bed AMB_NIGHT, continuous except SILENCE_01 · Flow clip audio discarded · −14 LUFS integrated, VO peaks ≈ −3 dB, light VO compression · no music

## Cover

SHOT_09, AFTER "bag of gold" (38.767s)

## End card

SHOT_22 — BLACK, PREVIOUS_SHOT_END → FIXED_DURATION 2.0s (108.000–110.000s), TEXT_05 @FatherGeula, SFX_BELL at the cut. `end_card_shot_id`: SHOT_22.
