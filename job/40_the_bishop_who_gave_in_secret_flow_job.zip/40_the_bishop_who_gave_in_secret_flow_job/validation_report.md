# VALIDATION REPORT — 40 - THE BISHOP WHO GAVE IN SECRET

## Overall status

**PASS**

Errors: 0 · Warnings: 7

### Warnings

- Near-ceiling: SHOT_10 target 7.421s (>= 7.000s) — noted in its generation_notes; the full ~8s Flow clip must be kept; underlength_behavior ERROR.
- Near-ceiling: SHOT_16 target 7.261s (>= 7.000s) — noted in its generation_notes; the full ~8s Flow clip must be kept; underlength_behavior ERROR.
- TEXT_03 is an excerpt of Matthew 6:3 (KJV). The VO speaks 'When thou doest alms, let not thy left hand know what thy right hand doeth.' The full verse reads 'But when thou doest alms, let not thy left hand know what thy right hand doeth:' — the card shows exactly the spoken words, labelled '(excerpt)', verse number added to the spoken 'Matthew six'. Verified word-for-word at biblehub.com/kjv/matthew/6-3.htm and bible.com/bible/1/MAT.6.3-4.KJV.
- No specific named icon, fresco, relic or church in the script: no REAL FOOTAGE NEEDED flags. 'Myra' is a named place: SHOT_03 is a generic atmospheric evocation of a Lycian coastal town, not documentary Myra/Demre; swap in real Demre footage only if exact identification is ever wanted. SHOT_05's bishop icon, SHOT_14's manuscript and SHOT_21's icon are generic, unnamed works.
- SHOT_01 shows a generic red holiday costume on a faceless mannequin: no character face, no brand, logo or lettering. It stands for the modern myth, not any specific depiction.
- Historical figures (the bishop SHOT_02/09/11/12, the father SHOT_06/10, the daughters SHOT_07) are hooded, from behind, silhouetted or hands-only; the bishop's face is never shown. The modern men (SHOT_15/16/19/20) are anonymous. None is fed the CHARACTER_SHEET.
- SHOT_13 and SHOT_18 are BLACK content cards ('Tell no one.'; Scripture) and consume no generation slot. SHOT_18 runs 8.882s, which is allowed for BLACK. The end card SHOT_22 is a separate 2.0s BLACK shot.

## Timeline integrity

- [x] shot IDs sequential SHOT_01..SHOT_22
- [x] every shot has a valid source (own SHOT id or BLACK)
- [x] every non-BLACK source appears in a generation manifest exactly once
- [x] no generated source video used twice
- [x] contiguous timeline (first at VIDEO_START, then PREVIOUS_SHOT_END, strictly increasing) — independently re-resolved
- [x] pre_roll_sec 0.0; no manual offsets on alignment timestamps
- [x] last VO shot (SHOT_21) ends at VO_AUDIO_END (108.000s), end card follows
- [x] end_card_shot_id points at the 2.0s BLACK end card SHOT_22
- [x] every spoken word (249) covered exactly once, in order

## Shot durations

- [x] no generated target > 8.000s (longest: SHOT_10 7.421s)
- [x] every target >= 7.000s listed in generation notes and warnings — Near-ceiling: SHOT_10 (7.421s), SHOT_16 (7.261s)
- [x] generation notes state the computed duration; manifest targets equal edit_spec targets
- [x] no fake duration manufacture (playback_rate 1.0, TRIM_END, underlength ERROR)
- [x] BLACK SHOT_13 (2.040s), SHOT_18 (8.882s) and SHOT_22 (2.000s) consume no generation slot

## Anchor validation

- [x] all 21 distinct phrase anchors resolve exactly once under both tokenisation variants (punctuation-only tokens dropped / kept)
- [x] no low-confidence [?] words in this alignment (0); none used
- [x] no anchor spans the em-dash token
- [x] repeated phrases disambiguated ('he was a bishop' vs 'he was a man'; 'Bishop of Myra' vs 'a bishop who' / 'the bishop'; 'And Nicholas asked' vs 'Nicholas.'; 'One night' vs 'another night'; 'We cannot fast' vs 'We cannot give'; 'Not your friends' vs 'Not your feed' / 'Not even'; 'Let your Father' vs 'the father was waiting')
- [x] only allowed timing types; no VO_START / VO_END

| Anchor | Words | Start | End |
|---|---|---|---|
| "he was a bishop" | 10–13 | 3.741s | 4.681s |
| "Bishop of Myra" | 22–24 | 9.042s | 10.122s |
| "We know very little" | 37–40 | 15.383s | 16.503s |
| "But the Church has" | 45–48 | 18.483s | 19.344s |
| "A man in his town" | 60–64 | 23.904s | 24.925s |
| "He had three daughters" | 69–72 | 26.945s | 28.225s |
| "and no future" | 86–88 | 33.826s | 34.746s |
| "One night" | 93–94 | 36.947s | 37.447s |
| "Then another night" | 103–105 | 41.508s | 42.948s |
| "He ran out" | 115–117 | 48.929s | 49.629s |
| "And Nicholas asked" | 133–135 | 55.550s | 56.530s |
| "Tell no one" | 140–142 | 58.331s | 59.171s |
| "That part did not work" | 143–147 | 60.371s | 61.711s |
| "Now look at us" | 155–158 | 64.932s | 65.752s |
| "We cannot fast" | 167–169 | 69.513s | 70.713s |
| "I include myself" | 181–183 | 76.774s | 77.854s |
| "When thou doest" | 194–196 | 83.075s | 83.976s |
| "So this week" | 211–213 | 91.957s | 92.717s |
| "Not your friends" | 225–227 | 97.058s | 97.918s |
| "Let your Father" | 242–244 | 103.799s | 104.519s |
| "bag of gold" | 96–98 | 37.887s | 38.767s |

## Text validation

- [x] exact content: TEXT_02 and TEXT_03 reproduce the spoken words; TEXT_01 HOOK and TEXT_04 STATEMENT are short and accurate to the VO
- [x] valid style enums (HOOK, STATEMENT, SCRIPTURE, HANDLE) and placement enums (LOWER_THIRD, BLACK_CARD_CENTER, CENTER_LOW, BLACK_CARD_CENTER_SMALL)
- [x] exact IN/OUT anchors (see editing_summary.md)
- [x] scripture verified and marked excerpt: 'When thou doest alms, let not thy left hand know what thy right hand doeth.' — Matthew 6:3 (excerpt). KJV full verse: 'But when thou doest alms, let not thy left hand know what thy right hand doeth:' — identical at biblehub.com/kjv/matthew/6-3.htm and bible.com/bible/1/MAT.6.3-4.KJV. Never certified as the complete verse.
- [x] every scripture quote carries its citation as its final line
- [x] no TRANSLATION cards; every fallback is null
- [x] HOOK/STATEMENT ≤ 4 lines; no blank or leading/trailing line breaks

## Audio validation

- [x] exactly one approved bed (AMB_NIGHT)
- [x] 3 approved executable accents (SFX_FOOTSTEP, SFX_CLOTH, SFX_BELL — bell only at the final cut to black)
- [x] one intentional silence event (Scripture card); natural pauses are not silence events
- [x] no accent fires inside SILENCE_01 (83.075–91.957s)
- [x] Flow clip audio discarded (discard_source_clip_audio true)
- [x] no music; library_suggestions are non-executable

## Clip policy

- [x] no loop, no reuse, no reverse, no freeze, no speed manipulation
- [x] hard cuts only; no forbidden transitions; black is BLACK shots
- [x] one generated camera move only (SHOT_03 slow push-in)

## Batch validation

- [x] exactly four batches (5 / 5 / 4 / 5 = 19 generated shots ≤ 20); not a [⚠️SMALL] job
- [x] max five planned video shots each; the spare slot sits in BATCH_03 with the riskiest shot (SHOT_11, two figures and a hand on a cloak)
- [x] still dependencies valid: every shot's still is in its own batch; 19 unique stills, none duplicated across batches
- [x] no reuse groups, so none split; no imported stills
- [x] output filenames exactly clips/SHOT_XX.mp4
- [x] concatenated timeline orders contiguous [1…19]
- [x] CHARACTER_SHEET present exactly where required: STILL_D, STILL_P, STILL_S (Father Geula); asset declared in BATCH_01 and BATCH_04 only, the batches that hold them; never on anonymous figures

## Safety

- [x] no violence, gore, wounds or weapons; the 'caught' moment is a calm hand on a cloak, no struggle
- [x] no real identifiable living people; historical figures hooded, from behind, silhouetted or hands-only; modern men anonymous
- [x] no specific named icon/fresco/artwork imitated; generic Byzantine-style icons and a generic manuscript with illegible script
- [x] no brand or character imitation in SHOT_01 (generic costume, faceless mannequin, no lettering)
- [x] no text/subtitles generated inside Flow video; motion prompts carry no editing instructions and never name Father Geula
- [x] Father Geula motion prompts use 'silent natural breathing' and 'silent … flicker' only; positive phrasing; every shot with a person or implied person has a fallback
- [x] supplied subtitles.srt, voiceover.mp3, alignment.json, voice_alignment.json and character_sheet.jpg copied byte-for-byte (sha256 equal to bundle_manifest.json)

## Duplication Risk Audit

### Exact/near duplicates found

- Planning draft had a separate 'a second' shot (a second purse landing on the floor) next to SHOT_10's waiting father with purses — two purse close-ups back to back.
- Planning draft had the chase as running feet (SHOT_11) and the reveal as a hooded man turning (SHOT_12) — two night-street shots of the same moment.
- Planning draft had Father Geula seated in profile with a book (SHOT_04) and a manuscript macro (SHOT_14) — the book repeated as filler.
- Planning draft had two cold phone cut-aways for 'without making sure someone noticed' and 'Not your feed'.

### Redesigned duplicates

- 'a second' is carried by two purses already on the table in SHOT_10; one purse image, not two.
- Chase and reveal merged into SHOT_11 (hand on the cloak, the bishop's stole revealed); SHOT_12 became hands-only on the shoulder.
- Father Geula in SHOT_04 holds a prayer rope, not a book; the manuscript exists once (SHOT_14).
- The phone motif is limited to SHOT_15 and SHOT_16; 'Not your feed' plays on SHOT_20 (the man walking away), with no third phone shot.

### Intentional repetition retained

- Hooded bishop across SHOT_02 / SHOT_09 / SHOT_11: one character, three framings and actions (story continuity).
- SHOT_02 ↔ SHOT_20 callback: the giver walking away, then and now.
- Window → phone → doorstep (SHOT_09 / SHOT_15 / SHOT_19): one act, three meanings (hidden, performed, hidden again).
- The bare house of the father appears twice (SHOT_06 bowed, SHOT_10 waiting), different angle, action and props.
- Oil-lamp light recurs as the period's only light source, by design of the brand palette.

### Father Geula composition audit

- 3 of 19 generated shots: SHOT_04 seated strict profile, medium (no lens); SHOT_17 close frontal (lens); SHOT_21 wide kneeling from behind (no face).
- Chest-up frontal framing: once (SHOT_17). Direct gaze: once — the line that names the camera.
- Light varies: candle on the bench; hanging lamp above; red-glass vigil lamp. Backgrounds: cell wall, dark nave, chapel corner.
- No 'chest-up, staring into lens, candle on one side' filler.

### Repeated object audit

- Phone: 2 shots (SHOT_15 filming a coin; SHOT_16 filming prayer), each a different function; never filler.
- Candle/lamp: the period's only light; as the subject only in SHOT_05 (candles before the icon).
- Icon: SHOT_05 (generic bishop icon, memory) and SHOT_21 (small icon of Christ, prayer) — different works, different functions. No icon wall.
- Bible: not used. Cross: worn by Father Geula only.
- Hands: SHOT_05 (placing a candle), SHOT_09 (purse at the window), SHOT_12 (hand on shoulder), SHOT_15 (phone and coin), SHOT_19 (bag on doorstep) — five distinct actions, never consecutive.
- Verdict: meaningful variety inside one coherent film; no revision needed.

## Consistency

- [x] build_plan.md, manifests, Flow prompts, edit_spec.json, job_manifest.json and editing_summary.md generated from one shot table and cross-checked (0 discrepancies)
- [x] job_manifest.json expected clips = manifest shots = edit_spec non-BLACK shots; Flow prompts expect the same shot IDs and invent no assets; prompts include retry verification
- [x] package is self-contained; subtitles.srt referenced as subtitles.srt and unchanged
