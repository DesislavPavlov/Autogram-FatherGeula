# BUILD PLAN — 45 - THE CORNER OF YOUR ROOM

Content type: Daily Rhythm & Confessions (sermon / practical vocabulary, with a short historical passage). 22 timeline shots: 20 generated (4 batches x 5), 1 BLACK Scripture card, 1 BLACK end card. Duration 93.280s VO + 2.000s end card = 95.280s. pre_roll_sec 0.0. Bed AMB_NIGHT.

## Concept

The film moves between three rooms. It opens in the cold blue bedroom where the desk and the screen already stand like an altar: an empty room, an empty chair, a silhouette in the doorway as the monitor wakes, a man hunched toward it in a posture that is a bow. On 'For centuries' it hard-cuts to the warm world of an old wooden house: the corner facing the east window at dawn, a red glass lamp in front of a generic icon, the embroidered red cloth that makes 'red' and 'beautiful' the same thing on screen, the household praying with their backs to us, a visitor crossing himself before he greets anyone. Father Geula enters only when the script turns to the viewer ('You do not need a church in your flat, brother'), standing beside his own plain shelf, and later his hands fill his cheap lamp for the dry confession. The third room is the viewer's own flat, which slowly acquires one warm light: a match lighting a candle beside one icon, feet standing on the floorboards, the corner waiting in the dark, a man slowing as he walks past it. Matthew 6:6 is a black card: the door is shut. After it the cold room returns with the candle as a tiny point against the blazing screen, Father Geula is seen in profile facing the light ('what you face first'), hands clear the clutter, the man stands before the corner with the dark desk behind him, and the Reel closes on Father Geula's back as he stands before his own shelf in the film's one slow push-in. Palettes change on hard cuts only; the mixed frames in the man's flat are single compositions that hold both lights by design.

## What the alignment changed

- The opening list ('Look at it. The desk. The chair.') is 3.441s; it is one low-angle shot of desk and chair rather than three sub-second cuts.
- 'For centuries, Orthodox homes kept a different corner. One wall, facing east where it could.' runs 15.403–21.925s (6.522s) and stays one shot (the corner with its east window), cut at the 0.70s pause before 'An icon'. It is the longest generated shot and still under 7.000s.
- 'The Russians called it the red corner. In the old tongue, red also meant beautiful.' is 6.321s held on one shot under the TRANSLATION card.
- The Scripture plus its spoken reference and the 1.16s pause after 'Matthew six' runs 65.154–73.696s (8.542s). That exceeds one Flow clip, so it is a BLACK card (no generation slot) with the bed muted.
- The alignment reports 0 low-confidence words, so no anchor needed rerouting.

## Shot list

| Shot | Still | Palette | VO coverage | Target (s) | Creative note | Audio note |
|---|---|---|---|---|---|---|
| SHOT_01 | STILL_A | cold | Every man already has an altar in his room. | 3.981 | The room's altar: desk and screen in the dark. Hook. The script's opening image made literal: the desk and screen arranged like an altar in an empty room. HOOK card over SHOT_01-02. | AMB_NIGHT bed starts at video start. No accent. |
| SHOT_02 | STILL_B | cold | Look at it. The desk. The chair. | 3.441 | The desk and the empty chair, low angle. 'Look at it. The desk. The chair.' One shot holds both objects so the short list lands without three tiny cuts. | Bed continues. No accent. |
| SHOT_03 | STILL_C | cold | The screen that lights up the moment you walk in. | 3.540 | A man in the doorway as the screen wakes. 'The screen that lights up the moment you walk in.' The screen greets him like a shrine lamp; he is a silhouette. | Bed continues. No accent. |
| SHOT_04 | STILL_D | cold | You visit it every night. You bow to it… more or less. | 4.441 | Hunched toward the screen like a bow. 'You visit it every night. You bow to it... more or less.' The dry joke staged as posture: the hunch is the bow. | Bed continues. No accent. |
| SHOT_05 | STILL_E | warm | For centuries, Orthodox homes kept a different corner. One wall, facing east where it could. | 6.522 | Old wooden house: the corner facing east at dawn. Hard cut cold to warm on 'For centuries'. 'Orthodox homes kept a different corner. One wall, facing east where it could.' The east window carries 'facing east'. Generic Tier 1 icons. | Bed continues. No accent. |
| SHOT_06 | STILL_F | warm | An icon. A small lamp burning in front of it. | 4.121 | Macro: icon and red glass lamp. 'An icon. A small lamp burning in front of it.' Hold on the lamp: the red glass seeds the 'red corner' line that follows. | Bed continues. No accent. |
| SHOT_07 | STILL_G | warm | The Russians called it the red corner. In the old tongue, red also meant beautiful. | 6.321 | The beautiful corner: embroidered cloth and icons. 'The Russians called it the red corner. In the old tongue, red also meant beautiful.' The embroidered red cloth makes red and beautiful the same thing on screen. TRANSLATION card over it. Generic Tier 1 icons. | Bed continues. No accent. |
| SHOT_08 | STILL_H | warm | It was where the household stood to pray together. | 2.981 | The household praying together, from behind. 'It was where the household stood to pray together.' Faces unseen; the corner is shared, not private. | Bed continues. No accent. |
| SHOT_09 | STILL_I | warm | And a visitor would honour the icons… before he even greeted the family. | 5.081 | The visitor greets the icons first. 'And a visitor would honour the icons... before he even greeted the family.' The order of greeting shown as the order in the frame. | Bed continues. No accent. |
| SHOT_10 | STILL_J | warm | You do not need a church in your flat, brother. You need a corner. | 4.281 | Father Geula standing beside his shelf, address. Father Geula's first appearance, on 'You do not need a church in your flat, brother. You need a corner.' Medium standing frontal, with his own small corner already in frame. Cover frame. | Bed continues. No accent. |
| SHOT_11 | STILL_K | mixed | One icon. One candle or a little lamp. | 3.780 | A match lights a small candle beside one icon. 'One icon. One candle or a little lamp.' The first warm light in the man's own room: the act of lighting, not a still life. | SFX_CANDLE on 'One candle or a little lamp'. |
| SHOT_12 | STILL_L | mixed | A place where you stand. | 2.141 | Feet on the floorboards before the corner. 'A place where you stand.' Standing, literally: the feet are the whole sentence. | Bed continues. No accent. |
| SHOT_13 | STILL_M | warm | Mine is a shelf. The lamp is cheap, and some weeks I forget to fill it. | 5.161 | Father Geula's hands filling a cheap lamp. 'Mine is a shelf. The lamp is cheap, and some weeks I forget to fill it.' His own corner, and the confession, shown as the act of filling it. | Bed continues. No accent. |
| SHOT_14 | STILL_N | mixed | That does not matter. What matters is that the corner is there before you feel ready… | 4.941 | The corner waiting in the dark flat. 'That does not matter. What matters is that the corner is there before you feel ready...' The corner holds the frame by itself; nobody is in it yet. | Bed continues. No accent. |
| SHOT_15 | STILL_O | mixed | so that every time you walk past it, it asks you a question. | 4.421 | Walking past the corner, he slows. 'So that every time you walk past it, it asks you a question.' Both palettes in one frame by design: the choice is the question. | SFX_FOOTSTEP on 'every time you walk'. |
| SHOT_16 | BLACK | black | "Enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret." Matthew six. | 8.542 | BLACK Scripture card: Matthew 6:6 (excerpt). 'Enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret.' Matthew six. The door is shut: the screen goes black. TEXT_04 on black. | SILENCE_01 mutes the bed for the whole card. |
| SHOT_17 | STILL_P | cold | The screen will always be the brightest thing in your room. That is its job. | 5.141 | The bright screen and the small light in the corner. 'The screen will always be the brightest thing in your room. That is its job.' Callback to SHOT_01: the same kind of room, now with the small light in it. | Bed returns after SILENCE_01. No accent. |
| SHOT_18 | STILL_Q | warm | Your job is to decide what you face first. | 3.381 | Father Geula in profile, facing the light. 'Your job is to decide what you face first.' He is shown facing: profile turned to the light, not to the lens. | Bed continues. No accent. |
| SHOT_19 | STILL_R | cold | So clear one corner tonight. Put one icon there. | 3.980 | Hands clearing the clutter off a shelf. 'So clear one corner tonight. Put one icon there.' The clearing is the work; still in cold light because it is not done yet. | Bed continues. No accent. |
| SHOT_20 | STILL_S | mixed | Stand in front of it before you sit in front of anything else. | 3.561 | He stands before the corner, back to the desk. 'Stand in front of it before you sit in front of anything else.' The screen he used to face is dark behind him: he has turned around. | Bed continues. No accent. |
| SHOT_21 | STILL_T | warm | Build the corner, brother. Then show up to it. | 3.521 | Father Geula before his corner, slow push-in. 'Build the corner, brother. Then show up to it.' He does what he asked: shows up to his own shelf. The Reel's one generated camera move. Hard cut to the BLACK end card. | Bed continues to VO end. SFX_BELL at VO_AUDIO_END on the cut to black. |
| SHOT_22 | BLACK | black | — | 2.000 | End card: @FatherGeula (TEXT_07). | SFX_BELL on the cut at VO_AUDIO_END. |

## Sound

- Bed: AMB_NIGHT throughout. The piece is set at night in a man's room and turns on prayer; deep near-silence suits both the cold flat and the lamp-lit corners better than stone reverb, and there is no outdoor material for AMB_WIND.
- Accents (3): SFX_CANDLE on 'One candle or a little lamp' (SHOT_11, the match lights the candle); SFX_FOOTSTEP on 'every time you walk' (SHOT_15, walking past the corner); SFX_BELL at VO_AUDIO_END on the hard cut to the end card.
- Intentional silence: SILENCE_01 mutes the bed for the Matthew 6:6 black card (BEFORE 'Enter into thy closet' to BEFORE 'The screen will always'). No accent fires inside it. No other pause becomes a silence event.
- All Flow clip audio is discarded. No music.

## Flags

- No REAL FOOTAGE NEEDED: the script names no specific icon, church, fresco or relic ('the red corner' is a household custom). Every icon is a generic Tier 1 Byzantine-style work.
- Scripture card: Matthew 6:6 (KJV) EXCERPT, shown with ellipses and '(excerpt)', verified word-for-word against biblehub.com and bible.com (see validation_report.md).
- TRANSLATION card: Красный угол / krasny ugol / the beautiful corner (Cyrillic is supported; a 2-line fallback is supplied anyway).
- One generated camera move: SHOT_21 slow push-in.
- The anonymous young man is held consistent only by one repeated description (no reference sheet).
- All 20 generation slots are used; there is no spare slot.

## Duplication notes

- No still is reused: 20 unique stills, 20 unique source clips.
- Bookend / callback: SHOT_17 deliberately recalls SHOT_01 (the dark room ruled by the screen), now with a tiny candle in the far corner; the framing differs (SHOT_01 from the doorway onto the desk, SHOT_17 across the whole room with both lights).
- Bookend: Father Geula's plain shelf with one icon and a glass lamp appears in SHOT_10 (he stands beside it, facing us), SHOT_13 (his hands fill the lamp) and SHOT_21 (his back, facing it). Same set, three different functions: invitation, confession, practice.
- The man's corner recurs in SHOT_11, 12, 14, 15 and 20 as a progression: lit, stood at, waiting, passed, faced. Each is a different framing (macro hand, floor-level feet, frontal empty corner, hallway from behind, medium from behind).
