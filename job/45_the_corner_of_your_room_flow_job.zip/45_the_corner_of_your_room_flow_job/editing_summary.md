# EDITING SUMMARY — 45 - THE CORNER OF YOUR ROOM

Format 1080x1920, 30 fps, H.264. pre_roll_sec 0.0. Bed AMB_NIGHT. Hard cuts only. Total 95.280s.

## Timeline

| # | Shot | Position (s) | Duration (s) | Source | Start | End |
|---|---|---|---|---|---|---|
| 1 | SHOT_01 | 0.000–3.981 | 3.981 | SHOT_01 | VIDEO_START | BEFORE 'Look at it' |
| 2 | SHOT_02 | 3.981–7.422 | 3.441 | SHOT_02 | PREVIOUS_SHOT_END | BEFORE 'The screen that lights' |
| 3 | SHOT_03 | 7.422–10.962 | 3.540 | SHOT_03 | PREVIOUS_SHOT_END | BEFORE 'You visit it every' |
| 4 | SHOT_04 | 10.962–15.403 | 4.441 | SHOT_04 | PREVIOUS_SHOT_END | BEFORE 'For centuries' |
| 5 | SHOT_05 | 15.403–21.925 | 6.522 | SHOT_05 | PREVIOUS_SHOT_END | BEFORE 'An icon' |
| 6 | SHOT_06 | 21.925–26.046 | 4.121 | SHOT_06 | PREVIOUS_SHOT_END | BEFORE 'The Russians called' |
| 7 | SHOT_07 | 26.046–32.367 | 6.321 | SHOT_07 | PREVIOUS_SHOT_END | BEFORE 'It was where the household' |
| 8 | SHOT_08 | 32.367–35.348 | 2.981 | SHOT_08 | PREVIOUS_SHOT_END | BEFORE 'And a visitor' |
| 9 | SHOT_09 | 35.348–40.429 | 5.081 | SHOT_09 | PREVIOUS_SHOT_END | BEFORE 'You do not need a church' |
| 10 | SHOT_10 | 40.429–44.710 | 4.281 | SHOT_10 | PREVIOUS_SHOT_END | BEFORE 'One icon One candle' |
| 11 | SHOT_11 | 44.710–48.490 | 3.780 | SHOT_11 | PREVIOUS_SHOT_END | BEFORE 'A place where you stand' |
| 12 | SHOT_12 | 48.490–50.631 | 2.141 | SHOT_12 | PREVIOUS_SHOT_END | BEFORE 'Mine is a shelf' |
| 13 | SHOT_13 | 50.631–55.792 | 5.161 | SHOT_13 | PREVIOUS_SHOT_END | BEFORE 'That does not matter' |
| 14 | SHOT_14 | 55.792–60.733 | 4.941 | SHOT_14 | PREVIOUS_SHOT_END | BEFORE 'so that every time' |
| 15 | SHOT_15 | 60.733–65.154 | 4.421 | SHOT_15 | PREVIOUS_SHOT_END | BEFORE 'Enter into thy closet' |
| 16 | SHOT_16 | 65.154–73.696 | 8.542 | BLACK | PREVIOUS_SHOT_END | BEFORE 'The screen will always' |
| 17 | SHOT_17 | 73.696–78.837 | 5.141 | SHOT_17 | PREVIOUS_SHOT_END | BEFORE 'Your job is to decide' |
| 18 | SHOT_18 | 78.837–82.218 | 3.381 | SHOT_18 | PREVIOUS_SHOT_END | BEFORE 'So clear one corner' |
| 19 | SHOT_19 | 82.218–86.198 | 3.980 | SHOT_19 | PREVIOUS_SHOT_END | BEFORE 'Stand in front of it' |
| 20 | SHOT_20 | 86.198–89.759 | 3.561 | SHOT_20 | PREVIOUS_SHOT_END | BEFORE 'Build the corner' |
| 21 | SHOT_21 | 89.759–93.280 | 3.521 | SHOT_21 | PREVIOUS_SHOT_END | VO_AUDIO_END |
| 22 | SHOT_22 | 93.280–95.280 | 2.000 | BLACK | PREVIOUS_SHOT_END | FIXED_DURATION 2.0s |

## Text events

| ID | Style | Placement | Content | In | Out | Fallback |
|---|---|---|---|---|---|---|
| TEXT_01 | HOOK | LOWER_THIRD | Every man already / has an altar. | VIDEO_START | BEFORE 'The screen that lights' | null |
| TEXT_02 | TRANSLATION | CENTER_LOW | Красный угол / krasny ugol / the beautiful corner | ON 'The Russians called' | BEFORE 'It was where the household' | "krasny ugol\nthe beautiful corner" |
| TEXT_03 | STATEMENT | CENTER_LOW | One icon. / One lamp. / A place where you stand. | ON 'One icon One candle' | BEFORE 'Mine is a shelf' | null |
| TEXT_04 | SCRIPTURE | BLACK_CARD_CENTER | …enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret… / — Matthew 6:6 (excerpt) | ON 'Enter into thy closet' | BEFORE 'The screen will always' | null |
| TEXT_05 | STATEMENT | CENTER_LOW | Decide what you face first. | ON 'Your job is to decide' | BEFORE 'So clear one corner' | null |
| TEXT_06 | STATEMENT | CENTER_LOW | Build the corner. / Then show up to it. | ON 'Build the corner' | VO_AUDIO_END | null |
| TEXT_07 | HANDLE | BLACK_CARD_CENTER_SMALL | @FatherGeula | VO_AUDIO_END | FIXED_DURATION 2.0s | null |

## Silence events

- SILENCE_01 — BEFORE 'Enter into thy closet' → BEFORE 'The screen will always', mute_bed true (Matthew 6:6 black card, SHOT_16).

## Accent events

- ACCENT_01 SFX_CANDLE — ON 'One candle or a little lamp'
- ACCENT_02 SFX_FOOTSTEP — ON 'every time you walk'
- ACCENT_03 SFX_BELL — VO_AUDIO_END

## Cover

- SHOT_10 at AFTER 'need a corner' (Father Geula, standing beside his shelf).

## End card

- SHOT_22: BLACK, PREVIOUS_SHOT_END → FIXED_DURATION 2.0s, with TEXT_07 @FatherGeula and SFX_BELL on the cut.
