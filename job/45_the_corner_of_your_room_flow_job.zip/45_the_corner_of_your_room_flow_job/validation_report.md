# VALIDATION REPORT — 45 - THE CORNER OF YOUR ROOM

## Overall status

PASS

All checks below were run by script against the packaged files (edit_spec.json, the four manifests, the four Flow prompts, job_manifest.json, alignment.json, voice_alignment.json) and the bundle's sha256 list.

## Timeline integrity

- [OK] timeline contiguous: SHOT_01 starts VIDEO_START, every later shot PREVIOUS_SHOT_END, target durations match computed anchors
- [OK] timeline ends at VO_AUDIO_END + 2.0 end card (95.280s)
- [OK] 20 generated sources, each used once
- [OK] every shot has a valid source (its own SHOT id or BLACK)
- [OK] end_card_shot_id points to the final 2.0s BLACK shot
- [OK] pre_roll_sec 0.0
- [OK] manifest shots == generated edit_spec sources
- [OK] cover source exists in shot list and is generated

## Shot durations

- [OK] SHOT_01 generated target 3.981s <= 8.000
- [OK] SHOT_02 generated target 3.441s <= 8.000
- [OK] SHOT_03 generated target 3.540s <= 8.000
- [OK] SHOT_04 generated target 4.441s <= 8.000
- [OK] SHOT_05 generated target 6.522s <= 8.000
- [OK] SHOT_06 generated target 4.121s <= 8.000
- [OK] SHOT_07 generated target 6.321s <= 8.000
- [OK] SHOT_08 generated target 2.981s <= 8.000
- [OK] SHOT_09 generated target 5.081s <= 8.000
- [OK] SHOT_10 generated target 4.281s <= 8.000
- [OK] SHOT_11 generated target 3.780s <= 8.000
- [OK] SHOT_12 generated target 2.141s <= 8.000
- [OK] SHOT_13 generated target 5.161s <= 8.000
- [OK] SHOT_14 generated target 4.941s <= 8.000
- [OK] SHOT_15 generated target 4.421s <= 8.000
- [OK] SHOT_17 generated target 5.141s <= 8.000
- [OK] SHOT_18 generated target 3.381s <= 8.000
- [OK] SHOT_19 generated target 3.980s <= 8.000
- [OK] SHOT_20 generated target 3.561s <= 8.000
- [OK] SHOT_21 generated target 3.521s <= 8.000
- [OK] no generated shot >= 7.000s (no near-ceiling warning due)
- [OK] manifest target durations equal edit_spec
- [OK] generation notes state the computed target

- No generated shot is >= 7.000s, so there is no near-ceiling warning. Longest generated: SHOT_05 6.522s. BLACK SHOT_16 is 8.542s (no generation).

## Anchor validation

- [OK] all 64 timing objects use allowed types; no VO_START/VO_END
- [OK] no deprecated VO_START / VO_END anywhere
- [OK] every phrase anchor resolves exactly once (35 anchors, 23 distinct)
- [OK] no low-confidence word in any anchor (alignment has 0 low-confidence words)

- Low-confidence words: none in this alignment (voice_alignment.json low_confidence_words is empty, mean score 0.964).
- Repeated phrases disambiguated: 'One icon' occurs twice (#115-116, #224-225), so TEXT_03 and SHOT_10's end use 'One icon One candle'; 'The screen' occurs twice (#17-18, #194-195), so the anchors are 'The screen that lights' and 'The screen will always'; 'an icon' (#54-55) is distinct from 'an altar' (#5-6).

## Text validation

- [OK] text style/placement enums valid
- [OK] no blank/leading/trailing line breaks
- [OK] every fallback is null or a plain string
- [OK] fallback null on every non-TRANSLATION card
- [OK] TEXT_01 HOOK 2 line(s) <= 4
- [OK] TEXT_02 TRANSLATION has 3 lines (script, word, meaning) and a 2-line fallback
- [OK] TEXT_03 STATEMENT 3 line(s) <= 4
- [OK] TEXT_04 SCRIPTURE ends with its citation line '— Matthew 6:6 (excerpt)'
- [OK] TEXT_05 STATEMENT 1 line(s) <= 4
- [OK] TEXT_06 STATEMENT 2 line(s) <= 4
- [OK] TEXT_07 HANDLE one line @FatherGeula
- [OK] scripture card text equals the verified KJV excerpt (biblehub + bible.com)
- [OK] scripture card wording equals the spoken VO wording
- [OK] excerpt marked with ellipses and '(excerpt)'; not certified as a complete verse

- Scripture verification (EXCERPT, not certified as a complete verse):
  - Matthew 6:6 (KJV), excerpt — "enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret" — biblehub.com/kjv/matthew/6-6.htm and bible.com/bible/1/MAT.6.6.KJV agree word-for-word on the excerpt. The full verse opens 'But thou, when thou prayest,' and continues '; and thy Father which seeth in secret shall reward thee openly.' The card shows ellipses at both ends and the citation '— Matthew 6:6 (excerpt)'.
- TEXT_04 is BLACK_CARD_CENTER over BLACK SHOT_16. TEXT_02 TRANSLATION is 3 lines (Cyrillic, transliteration, meaning); Cyrillic is supported by the renderer font and the 2-line fallback 'krasny ugol / the beautiful corner' is supplied as a plain string.

## Audio validation

- [OK] one approved bed (AMB_NIGHT); Flow audio discarded
- [OK] <= 3 approved accents
- [OK] no accent fires inside the silence event
- [OK] one intentional silence event (Scripture black card)
- [OK] no music/riser/boom in the executable audio (bed, mix, accents)

- SILENCE_01 is the only silence event and is intentional (the Matthew 6:6 black card). No other measured pause is a silence event.
- No music, booms, risers or score; SFX_BELL used once, on the final cut to black.

## Clip policy

- [OK] source clip policy unchanged

- [OK] playback_rate 1.0, TRIM_END / ERROR unchanged; no loop, reuse, reverse, freeze or speed change.
- [OK] Every cut is a hard cut; black is a BLACK shot; no transitions requested anywhere.

## Batch validation

- [OK] exactly four manifests, each <= 5 shots, counts match
- [OK] no still duplicated across batches
- [OK] every shot's still is in its own batch
- [OK] output filenames exact clips/SHOT_XX.mp4
- [OK] timeline_order equals edit_spec timeline position
- [OK] generated orders + BLACK positions form contiguous [1..22]
- [OK] job_manifest expected clips == generated shots
- [OK] job_manifest batch shot lists == manifests
- [OK] BATCH_01.txt expects exactly the manifest's stills and shots
- [OK] BATCH_01.txt prompts verbatim from manifest
- [OK] BATCH_01.txt includes retry + end-of-batch verification
- [OK] BATCH_01 CHARACTER_SHEET asset present iff needed (not needed)
- [OK] BATCH_02.txt expects exactly the manifest's stills and shots
- [OK] BATCH_02.txt prompts verbatim from manifest
- [OK] BATCH_02.txt includes retry + end-of-batch verification
- [OK] BATCH_02 CHARACTER_SHEET asset present iff needed (needed)
- [OK] BATCH_03.txt expects exactly the manifest's stills and shots
- [OK] BATCH_03.txt prompts verbatim from manifest
- [OK] BATCH_03.txt includes retry + end-of-batch verification
- [OK] BATCH_03 CHARACTER_SHEET asset present iff needed (needed)
- [OK] BATCH_04.txt expects exactly the manifest's stills and shots
- [OK] BATCH_04.txt prompts verbatim from manifest
- [OK] BATCH_04.txt includes retry + end-of-batch verification
- [OK] BATCH_04 CHARACTER_SHEET asset present iff needed (needed)
- [OK] CHARACTER_SHEET used exactly on Father Geula stills (SHOT_10, 13, 18, 21); never on anonymous figures
- [OK] reference_assets consistent with character_sheet_required
- [OK] job_manifest references subtitles.srt and character_sheet.jpg

- Reuse groups: none (20 unique stills), so none can be split. Batches are chronological: BATCH_01 = SHOT_01-05 (no Father Geula, so no CHARACTER_SHEET asset), BATCH_02 = SHOT_06-10, BATCH_03 = SHOT_11-15, BATCH_04 = SHOT_17-21. Position 16 is BLACK SHOT_16 and position 22 is the BLACK end card.
- [⚠️SMALL] flag not due: every batch has 5 videos.

## Automation and prompts

- [OK] every still prompt starts 'Vertical 9:16'
- [OK] every still prompt carries film style + austerity
- [OK] full Father Geula description in every full-figure FG still (SHOT_13 is hands-only and carries the forearm/sleeve/cross description)
- [OK] motion prompts: positive phrasing only (no negations)
- [OK] motion prompts never name Father Geula
- [OK] motion prompts contain no editorial instructions
- [OK] standing rule: no 'gentle natural breathing' / 'flickers softly'
- [OK] Father Geula face/figure shots use 'silent natural breathing' and 'silent lamp flicker'
- [OK] every shot with a person/face/implied person has a fallback
- [OK] exactly one generated camera move (SHOT_21 slow push-in)

## Package and inputs

- [OK] voiceover.mp3 copied byte-for-byte (sha256 matches bundle)
- [OK] alignment.json copied byte-for-byte (sha256 matches bundle)
- [OK] subtitles.srt copied byte-for-byte (sha256 matches bundle)
- [OK] voice_alignment.json copied byte-for-byte (sha256 matches bundle)
- [OK] character_sheet.jpg copied byte-for-byte (sha256 matches bundle)

## Safety

- [OK] No violence, weapons, wounds or gore anywhere in the plan.
- [OK] No real identifiable living people. The anonymous man, the historical family and the visitor are faces-unseen or silhouetted; only Father Geula (the brand's own character) shows his face.
- [OK] Icons are generic Tier 1 Byzantine-style works; no named icon, fresco, relic or church is imitated, so no REAL FOOTAGE NEEDED flag is due.
- [OK] Scripture is an excerpt, labelled as such, and verified against two independent sources.
- [OK] Character sheet only on Father Geula stills.

## Duplication Risk Audit

### Exact/near duplicates found

- During planning, the man's hands placing an icon on a shelf (for 'One icon. One candle') and his hands clearing the shelf (for 'So clear one corner tonight. Put one icon there.') would have been two takes of the same hand-at-shelf setup.
- The draft also had Father Geula in profile twice (for 'What matters is that the corner is there' and for 'what you face first').
- The macro of an icon with its lamp in the old house (SHOT_06) and a still life of icon and candle on the modern shelf risked reading as the same object shot twice.

### Redesigned duplicates

- 'One icon. One candle or a little lamp' became SHOT_11: a match being struck to light a candle (an act, warm flame in a cold room). 'So clear one corner' stayed as SHOT_19: two hands sweeping cans and cables into a box in cold light. Different action, palette and framing.
- The first profile was replaced with SHOT_14, the empty corner waiting in the dark flat (environment, no person). Father Geula's only profile is SHOT_18.
- The modern-shelf still life was dropped in favour of the match action; SHOT_06 stays the only icon-and-lamp macro.

### Intentional repetition retained

- SHOT_01 / SHOT_17: callback to the screen-ruled room, now with the candle in it (different framing and content).
- Father Geula's own shelf in SHOT_10, SHOT_13 and SHOT_21: one set, three functions (invitation, confession, practice), bookending his part of the film.
- The man's corner in SHOT_11, 12, 14, 15, 20: a deliberate progression (lit, stood at, waiting, passed, faced), each in a different framing.

### Father Geula composition audit

- 4 appearances: SHOT_10 medium standing frontal (address), SHOT_13 hands-only close-up (object interaction), SHOT_18 strict-profile close-up, SHOT_21 wide full-body from behind with the push-in. Only one frontal direct gaze; no repeated chest-up-with-candle composition.

### Repeated object audit

- Candle/lamp: it is the subject of the script (the lamp in the corner), so it recurs, but each time with a different function: shrine lamp in history (SHOT_05-09), his cheap lamp being filled (SHOT_13), the man's first candle being lit (SHOT_11), the waiting light (SHOT_14), the tiny point against the screen (SHOT_17).
- Icons: always generic; in close-up only once (SHOT_06).
- Phone/screen: the monitor is the 'altar' of the cold world (SHOT_01-04, 17) and is switched off in SHOT_20.
- Hands: three hand shots (SHOT_11 match, SHOT_13 oil, SHOT_19 clearing), each a different action. No Bible or cross filler; the cross appears only on Father Geula.

The plan reads as one coherent film; no further revision needed.
