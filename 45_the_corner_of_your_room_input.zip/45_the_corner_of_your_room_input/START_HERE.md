# Father Geula — input bundle: 45 - THE CORNER OF YOUR ROOM

- **Job slug:** `45_the_corner_of_your_room`
- **Deliverable:** `45_the_corner_of_your_room_flow_job.zip`, built exactly as `MASTER_PROMPT.md` specifies.

## What this is
`MASTER_PROMPT.md` is the complete production specification. Read all of it before planning. Every input its Part 1 lists is in this bundle, already named the way its Part 29 packaging expects:

| Master prompt input | File in this bundle |
|---|---|
| Finished ElevenLabs v3-scored script | `elevenlabs_script.txt` |
| Final voiceover audio | `voiceover.mp3` |
| voice_alignment.json — creative timing authority | `voice_alignment.json` |
| alignment.json — renderer handoff | `alignment.json` |
| Subtitle file (.srt) | `subtitles.srt` |
| Father Geula character sheet | `character_sheet.jpg` |

Copy `voiceover.mp3`, `alignment.json`, `subtitles.srt`, `voice_alignment.json` and `character_sheet.jpg` into the job package byte-for-byte. `bundle_manifest.json` has a sha256 for each.

## Alignment facts
- Audio duration **93.280s** · speech 0.140s → 92.940s
- Alignment QC: **OK**, mean confidence 0.96
- 0 low-confidence word(s) — these are the `[?]` words of Part 6, listed in `voice_alignment.json → low_confidence_words`.
- 37 sentences · 40 pauses ≥ 0.35s · 16 v3 performance tag(s) placed in the timeline
- Phrase anchors resolve against the words in `alignment.json` — the spoken wording with v3 tags removed — not against `elevenlabs_script.txt`.
- Script: ElevenLabs v3 script with audio tags; the tags were removed before alignment and their positions are in voice_alignment.json → performance_tags.
